import os
import json
import time
import requests
import subprocess
from typing import Dict, List, Optional, Union, Tuple, Any
from flask import current_app
from app.models import db, APITransaction, MetasploitSession, BurpIssueFinding
from datetime import datetime

# API Interface abstract class
class ToolAPI:
    """Base class for security tool API integrations"""
    def __init__(self, user_id: Optional[int] = None):
        self.user_id = user_id
        self.tool_name = "base"

    def _log_api_call(self, endpoint: str, request_data: str, response_data: str,
                    status_code: int, success: bool, error_message: str = None,
                    execution_time: float = 0.0) -> APITransaction:
        """Log API call to the database"""
        transaction = APITransaction(
            tool_name=self.tool_name,
            endpoint=endpoint,
            request_data=request_data,
            response_data=response_data,
            status_code=status_code,
            success=success,
            error_message=error_message,
            execution_time=execution_time,
            user_id=self.user_id
        )

        db.session.add(transaction)
        db.session.commit()

        return transaction

# Metasploit RPC API Interface
class MetasploitAPI(ToolAPI):
    """Interface for Metasploit RPC API"""
    def __init__(self, user_id: Optional[int] = None):
        super().__init__(user_id)
        self.tool_name = "metasploit"
        self.api_url = current_app.config['API_ENDPOINTS'].get('metasploit')
        self.api_key = current_app.config['API_KEYS'].get('metasploit')
        self.token = None

    def auth_login(self, username: str = "msf", password: str = "password") -> bool:
        """Authenticate with the Metasploit RPC API"""
        endpoint = "auth/login"
        request_data = {
            "username": username,
            "password": password
        }

        start_time = time.time()
        success = False
        response_data = {}
        status_code = 0
        error_message = None

        try:
            # In a real implementation, this would make an actual API call
            # This is a simulation for demo purposes

            # Simulated API call
            # response = requests.post(f"{self.api_url}/{endpoint}",
            #                        json=request_data,
            #                        headers={"Authorization": f"Bearer {self.api_key}"})
            # response.raise_for_status()
            # response_data = response.json()

            # Simulated response
            self.token = "SIMULATED_TOKEN"
            response_data = {"token": self.token, "success": True}
            status_code = 200
            success = True

        except Exception as e:
            error_message = str(e)
            response_data = {"error": error_message}
            status_code = 500

        execution_time = time.time() - start_time

        # Log the API call
        self._log_api_call(
            endpoint=endpoint,
            request_data=json.dumps(request_data),
            response_data=json.dumps(response_data),
            status_code=status_code,
            success=success,
            error_message=error_message,
            execution_time=execution_time
        )

        return success

    def create_session(self, target_host: str, target_port: int,
                     payload: str = "generic/shell_reverse_tcp") -> Dict:
        """Create a new Metasploit session"""
        if not self.token:
            success = self.auth_login()
            if not success:
                return {"success": False, "error": "Authentication failed"}

        endpoint = "sessions/create"
        request_data = {
            "target_host": target_host,
            "target_port": target_port,
            "payload": payload
        }

        start_time = time.time()
        success = False
        response_data = {}
        status_code = 0
        error_message = None
        session_info = None

        try:
            # Simulated API call for demo purposes
            session_id = f"MS{int(time.time())}"
            response_data = {
                "success": True,
                "session_id": session_id,
                "session_type": "shell",
                "target_host": target_host,
                "target_port": target_port
            }
            status_code = 200
            success = True

            # Create session record in database
            session_record = MetasploitSession(
                session_id=session_id,
                session_type="shell",
                target_host=target_host,
                target_port=target_port,
                user_id=self.user_id,
                is_active=True
            )

            session_record.set_metadata_dict({
                "payload": payload,
                "creation_time": datetime.utcnow().isoformat()
            })

            db.session.add(session_record)
            db.session.commit()

            session_info = {
                "session_id": session_id,
                "target_host": target_host,
                "target_port": target_port
            }

        except Exception as e:
            error_message = str(e)
            response_data = {"error": error_message}
            status_code = 500

        execution_time = time.time() - start_time

        # Log the API call
        self._log_api_call(
            endpoint=endpoint,
            request_data=json.dumps(request_data),
            response_data=json.dumps(response_data),
            status_code=status_code,
            success=success,
            error_message=error_message,
            execution_time=execution_time
        )

        if session_info:
            return {"success": True, "session": session_info}
        else:
            return {"success": False, "error": error_message or "Failed to create session"}

# Burp Suite API Interface
class BurpSuiteAPI(ToolAPI):
    """Interface for Burp Suite Enterprise/Professional API"""
    def __init__(self, user_id: Optional[int] = None):
        super().__init__(user_id)
        self.tool_name = "burpsuite"
        self.api_url = current_app.config['API_ENDPOINTS'].get('burpsuite')
        self.api_key = current_app.config['API_KEYS'].get('burpsuite')

    def scan_url(self, target_url: str) -> Dict:
        """Start a scan of a target URL"""
        endpoint = "scan"
        request_data = {
            "urls": [target_url],
            "scan_configurations": ["otp_detection", "default"]
        }

        start_time = time.time()
        success = False
        response_data = {}
        status_code = 0
        error_message = None

        try:
            # Simulated API call for demo purposes
            scan_id = f"SCAN-{int(time.time())}"
            response_data = {
                "success": True,
                "scan_id": scan_id,
                "message": f"Scan started for {target_url}"
            }
            status_code = 200
            success = True

        except Exception as e:
            error_message = str(e)
            response_data = {"error": error_message}
            status_code = 500

        execution_time = time.time() - start_time

        # Log the API call
        self._log_api_call(
            endpoint=endpoint,
            request_data=json.dumps(request_data),
            response_data=json.dumps(response_data),
            status_code=status_code,
            success=success,
            error_message=error_message,
            execution_time=execution_time
        )

        if success:
            return {"success": True, "scan_id": response_data.get("scan_id")}
        else:
            return {"success": False, "error": error_message or "Failed to start scan"}

    def get_scan_issues(self, scan_id: str) -> Dict:
        """Get issues found in a scan"""
        endpoint = f"scan/{scan_id}/issues"
        request_data = {}

        start_time = time.time()
        success = False
        response_data = {}
        status_code = 0
        error_message = None

        try:
            # Simulated API call for demo purposes
            issues = []
            # Simulated finding for OTP-related vulnerability
            otp_finding = {
                "issue_type": "otp_detection",
                "issue_name": "OTP Form Detected",
                "severity": "Information",
                "confidence": "Firm",
                "host": "example.com",
                "path": "/login/verification",
                "description": "A form that appears to collect one-time passwords was detected.",
                "remediation": "Ensure proper rate limiting and lockout policies are applied to OTP forms.",
                "request_data": "POST /login/verification HTTP/1.1\nHost: example.com\n\ncode=",
                "response_data": "HTTP/1.1 200 OK\nContent-Type: text/html\n\n<html><body>Verification successful</body></html>"
            }
            issues.append(otp_finding)

            response_data = {
                "success": True,
                "issues": issues
            }
            status_code = 200
            success = True

            # Store the findings in the database
            for issue in issues:
                finding = BurpIssueFinding(
                    scan_id=scan_id,
                    issue_type=issue.get("issue_type"),
                    issue_name=issue.get("issue_name"),
                    severity=issue.get("severity"),
                    confidence=issue.get("confidence"),
                    host=issue.get("host"),
                    path=issue.get("path"),
                    description=issue.get("description"),
                    remediation=issue.get("remediation"),
                    request_data=issue.get("request_data"),
                    response_data=issue.get("response_data"),
                    user_id=self.user_id
                )
                db.session.add(finding)

            db.session.commit()

        except Exception as e:
            error_message = str(e)
            response_data = {"error": error_message}
            status_code = 500

        execution_time = time.time() - start_time

        # Log the API call
        self._log_api_call(
            endpoint=endpoint,
            request_data=json.dumps(request_data),
            response_data=json.dumps(response_data),
            status_code=status_code,
            success=success,
            error_message=error_message,
            execution_time=execution_time
        )

        if success:
            return {"success": True, "issues": response_data.get("issues", [])}
        else:
            return {"success": False, "error": error_message or "Failed to get scan issues"}

# ZAP API Interface
class ZAPAPI(ToolAPI):
    """Interface for OWASP ZAP API"""
    def __init__(self, user_id: Optional[int] = None):
        super().__init__(user_id)
        self.tool_name = "zap"
        self.api_url = current_app.config['API_ENDPOINTS'].get('zap')
        self.api_key = current_app.config['API_KEYS'].get('zap')

    def start_scan(self, target_url: str) -> Dict:
        """Start a ZAP scan"""
        endpoint = "ascan/scan"
        request_data = {
            "url": target_url,
            "apikey": self.api_key
        }

        start_time = time.time()
        success = False
        response_data = {}
        status_code = 0
        error_message = None

        try:
            # Simulated API call for demo purposes
            response_data = {
                "success": True,
                "scan_id": f"ZAP-{int(time.time())}",
            }
            status_code = 200
            success = True

        except Exception as e:
            error_message = str(e)
            response_data = {"error": error_message}
            status_code = 500

        execution_time = time.time() - start_time

        # Log the API call
        self._log_api_call(
            endpoint=endpoint,
            request_data=json.dumps(request_data),
            response_data=json.dumps(response_data),
            status_code=status_code,
            success=success,
            error_message=error_message,
            execution_time=execution_time
        )

        if success:
            return {"success": True, "scan_id": response_data.get("scan_id")}
        else:
            return {"success": False, "error": error_message or "Failed to start scan"}

    def search_otp_forms(self, target_url: str = None) -> Dict:
        """Search for OTP forms on target URL or in current session"""
        endpoint = "search/urlsByUrlRegex"
        request_data = {
            "regex": "(otp|verification|code|auth|token|pin)",
            "apikey": self.api_key,
            "baseurl": target_url
        }

        start_time = time.time()
        success = False
        response_data = {}
        status_code = 0
        error_message = None

        try:
            # Simulated API call for demo purposes
            response_data = {
                "success": True,
                "urls": [
                    f"{target_url}/verify-otp",
                    f"{target_url}/login/2fa",
                    f"{target_url}/confirm-code"
                ]
            }
            status_code = 200
            success = True

        except Exception as e:
            error_message = str(e)
            response_data = {"error": error_message}
            status_code = 500

        execution_time = time.time() - start_time

        # Log the API call
        self._log_api_call(
            endpoint=endpoint,
            request_data=json.dumps(request_data),
            response_data=json.dumps(response_data),
            status_code=status_code,
            success=success,
            error_message=error_message,
            execution_time=execution_time
        )

        if success:
            return {"success": True, "urls": response_data.get("urls", [])}
        else:
            return {"success": False, "error": error_message or "Failed to search for OTP forms"}
