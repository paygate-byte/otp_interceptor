from flask import render_template, request, redirect, url_for, flash, session, current_app
from app import app, db
from app.models import User, ActivityLog
from app.utils import log_activity
from datetime import datetime

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page with updated credentials"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Valid username is COLLINS and password is Otp@001
        user = User.query.filter_by(username=username).first()

        if user and user.verify_password(password):
            # Update last login timestamp
            user.last_login = datetime.utcnow()
            db.session.commit()

            # Set user session
            session['user_id'] = user.id
            session['username'] = user.username
            session['is_admin'] = user.is_admin

            # Log the successful login
            log_activity(
                user_id=user.id,
                activity_type='login',
                description=f'User {user.username} logged in successfully',
                ip_address=request.remote_addr
            )

            flash('Login successful', 'success')
            return redirect(url_for('index'))
        else:
            # Log the failed login attempt
            log_activity(
                user_id=None,
                activity_type='login_failed',
                description=f'Failed login attempt for username: {username}',
                ip_address=request.remote_addr
            )

            flash('Invalid credentials. Please try again.', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    """Logout route"""
    user_id = session.get('user_id')
    username = session.get('username')

    if user_id:
        # Log the logout
        log_activity(
            user_id=user_id,
            activity_type='logout',
            description=f'User {username} logged out',
            ip_address=request.remote_addr
        )

    # Clear session
    session.clear()

    flash('Logged out successfully', 'success')
    return redirect(url_for('login'))
