import os
import re
import json
import time
import random
import subprocess
from typing import Dict, List, Optional, Union, Tuple, Any
from flask import current_app
from app.models import db, CapturedOTP, PCAPFile, PacketFilter
from datetime import datetime

class OTPDetector:
    """Class for OTP detection logic"""

    def __init__(self, user_id: Optional[int] = None):
        self.user_id = user_id
        self.patterns = current_app.config['OTP_PATTERNS']

    def detect_otp_from_text(self, text: str, source_type: str,
                           source_identifier: str) -> List[Dict]:
        """
        Find potential OTPs in text using regex patterns
        Returns a list of dictionaries with OTP values and confidence
        """
        results = []

        if not text:
            return results

        # Process text to find OTPs
        for pattern in self.patterns:
            matches = re.finditer(pattern, text)
            for match in matches:
                # Extract the matched OTP - it could be in a group or the whole match
                if match.groups():
                    otp_value = match.group(1)  # Assuming the first group is the OTP
                else:
                    otp_value = match.group(0)

                # Calculate confidence based on context
                confidence = self._calculate_confidence(text, otp_value, match.start())

                # Store the result
                result = {
                    'otp_value': otp_value,
                    'confidence': confidence,
                    'pattern': pattern,
                    'position': match.start(),
                    'context': text[max(0, match.start()-30):min(len(text), match.end()+30)]
                }

                results.append(result)

        # Store the OTPs in the database if they have sufficient confidence
        stored_otps = []
        for result in results:
            if result['confidence'] >= 0.5:  # Minimum confidence threshold
                otp_db = CapturedOTP(
                    otp_value=result['otp_value'],
                    source_type=source_type,
                    source_identifier=source_identifier,
                    confidence=result['confidence'],
                    detection_method='regex_pattern',
                    tool_used='otp_detector',
                    raw_data=text[:1000],  # Store first 1000 chars to avoid huge data
                    user_id=self.user_id
                )

                # Store metadata
                metadata = {
                    'pattern': result['pattern'],
                    'position': result['position'],
                    'context': result['context']
                }
                otp_db.set_metadata_dict(metadata)

                db.session.add(otp_db)
                stored_otps.append(otp_db)

        if stored_otps:
            db.session.commit()

        return results

    def _calculate_confidence(self, text: str, otp: str, position: int) -> float:
        """
        Calculate confidence score for a potential OTP based on context
        Returns a value between 0.0 and 1.0
        """
        base_confidence = 0.5  # Start with medium confidence

        # Consider the OTP length
        if len(otp) == 6:
            base_confidence += 0.2  # 6-digit OTPs are common
        elif len(otp) == 4:
            base_confidence += 0.1  # 4-digit OTPs are also common

        # Consider the context around the OTP
        context_window = text[max(0, position-50):min(len(text), position+50)]

        # Check for common OTP-related terms in context
        otp_keywords = [
            'verification', 'code', 'otp', 'password', 'token',
            'verify', 'authenticate', 'security', 'login', 'pin', 'one-time'
        ]

        for keyword in otp_keywords:
            if re.search(rf'\b{keyword}\b', context_window, re.IGNORECASE):
                base_confidence += 0.05

        # Check for expiration-related terms
        if re.search(r'expire|valid for|minutes|seconds', context_window, re.IGNORECASE):
            base_confidence += 0.1

        # Reduce confidence if there are too many numbers in the context
        number_matches = re.findall(r'\b\d{4,8}\b', context_window)
        if len(number_matches) > 2:  # More than 2 number sequences might be a coincidence
            base_confidence -= 0.1 * (len(number_matches) - 2)

        # Ensure confidence is between 0 and 1
        return max(0.0, min(0.99, base_confidence))  # Cap at 0.99 for safety

class PCAPAnalyzer:
    """Class for analyzing PCAP files for OTPs"""

    def __init__(self, user_id: Optional[int] = None):
        self.user_id = user_id
        self.otp_detector = OTPDetector(user_id)

    def analyze_pcap(self, pcap_file_path: str,
                   filter_expr: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze a PCAP file for OTPs
        Returns a dictionary with analysis results
        """
        # In a real implementation, this would use pyshark or subprocess to run tshark
        # For simulation, we'll create a dummy analysis

        # Record the analysis in the database
        pcap_record = PCAPFile(
            filename=os.path.basename(pcap_file_path),
            file_path=pcap_file_path,
            file_size=os.path.getsize(pcap_file_path),
            filter_used=filter_expr,
            packet_count=random.randint(100, 5000),
            user_id=self.user_id,
            last_analyzed=datetime.utcnow()
        )

        pcap_record.analysis_count = 1
        pcap_record.md5_hash = self._compute_file_hash(pcap_file_path)

        db.session.add(pcap_record)
        db.session.commit()

        # Simulate analysis results
        analysis_time = random.uniform(0.5, 5.0)

        # Simulate finding 1-3 OTPs
        potential_otps = []
        for _ in range(random.randint(1, 3)):
            otp_result = self._simulate_otp_detection(pcap_record.id)
            potential_otps.append(otp_result)

        results = {
            'pcap_id': pcap_record.id,
            'filename': pcap_record.filename,
            'packets_analyzed': pcap_record.packet_count,
            'potential_otps': potential_otps,
            'analysis_time': analysis_time,
            'filter_applied': filter_expr or 'http or https'
        }

        return results

    def _compute_file_hash(self, file_path: str) -> str:
        """Compute MD5 hash of a file - dummy implementation"""
        # In a real implementation, use hashlib.md5 to compute the hash
        return f"simulated_hash_{int(time.time())}"

    def _simulate_otp_detection(self, pcap_id: int) -> Dict:
        """Simulate detecting an OTP in a PCAP file"""
        source_types = ['web', 'sms', 'email']
        source_type = random.choice(source_types)

        # Generate random OTP (4-8 digits)
        otp_length = random.choice([4, 6, 8])
        otp = ''.join(random.choices('0123456789', k=otp_length))

        # Generate source identifier based on type
        if source_type == 'web':
            domains = ['example.com', 'secure-bank.com', 'shop-site.com', 'email-provider.net']
            paths = ['/login', '/verify', '/2fa', '/account']
            source_identifier = f"https://{random.choice(domains)}{random.choice(paths)}"
        elif source_type == 'sms':
            source_identifier = f"+1{random.randint(2000000000, 9999999999)}"
        else:  # email
            domains = ['gmail.com', 'outlook.com', 'yahoo.com', 'company.com']
            source_identifier = f"service@{random.choice(domains)}"

        # Generate simulated context
        contexts = [
            f"Your verification code is {otp}. It will expire in 10 minutes.",
            f"Use {otp} to complete your login. This code is valid for 5 minutes.",
            f"Your one-time password: {otp}",
            f"Security code: {otp} for your recent transaction.",
            f"<div>Verification Code</div><div>{otp}</div><div>Enter this code to verify your identity.</div>"
        ]
        context = random.choice(contexts)

        # Calculate confidence (between 0.75 and 0.98)
        confidence = random.uniform(0.75, 0.98)

        # Select a detection method
        methods = ['pattern_match', 'header_analysis', 'content_scan', 'form_field_analysis']
        method = random.choice(methods)

        # Create database record
        otp_record = CapturedOTP(
            otp_value=otp,
            source_type=source_type,
            source_identifier=source_identifier,
            confidence=confidence,
            detection_method=method,
            tool_used='pcap_analyzer',
            raw_data=context,
            pcap_id=pcap_id,
            user_id=self.user_id
        )

        metadata = {
            'packet_number': random.randint(1, 5000),
            'protocol': random.choice(['HTTP', 'HTTPS', 'TCP', 'UDP']),
            'timestamp': datetime.utcnow().isoformat(),
            'context': context
        }
        otp_record.set_metadata_dict(metadata)

        db.session.add(otp_record)
        db.session.commit()

        # Return a dictionary representation
        return {
            'otp': otp,
            'source': source_type,
            'source_identifier': source_identifier,
            'confidence': confidence,
            'timestamp': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
            'method': method,
            'context': context[:50] + '...' if len(context) > 50 else context
        }

class PacketFilterManager:
    """Class for managing Wireshark/tshark filters for OTP detection"""

    def __init__(self, user_id: Optional[int] = None):
        self.user_id = user_id

    def create_filter(self, name: str, filter_string: str,
                    description: str, is_otp_filter: bool = True,
                    tool: str = 'wireshark') -> PacketFilter:
        """Create a new packet filter"""
        filter_record = PacketFilter(
            name=name,
            filter_string=filter_string,
            description=description,
            is_otp_filter=is_otp_filter,
            tool=tool,
            user_id=self.user_id
        )

        db.session.add(filter_record)
        db.session.commit()

        return filter_record

    def get_default_otp_filters(self) -> Dict[str, str]:
        """Get default OTP detection filters for various tools"""
        return {
            'wireshark_http_otp': 'http contains "otp" or http contains "code" or http contains "token"',
            'wireshark_form_data': 'http.request.method == "POST" and tcp contains "otp"',
            'wireshark_sms_gateway': 'tcp port 80 and (tcp contains "sms" or tcp contains "text") and tcp contains "verification"',
            'tcpdump_otp': 'tcp port 80 or tcp port 443',
            'tshark_otp': '-Y "http contains \\"otp\\" or http contains \\"code\\" or http contains \\"token\\""',
            'ettercap_otp': 'if (ip.proto == TCP && tcp.dst == 80) { if (search(DATA.data, "otp=")) { log(DATA.data, "/tmp/otp.log"); } }'
        }

    def get_available_filters(self, tool: Optional[str] = None) -> List[PacketFilter]:
        """Get available packet filters, optionally filtered by tool"""
        query = PacketFilter.query

        if tool:
            query = query.filter_by(tool=tool)

        if self.user_id:
            query = query.filter((PacketFilter.user_id == self.user_id) | (PacketFilter.user_id == None))

        return query.all()

    def get_recommended_filter(self, source_type: str) -> str:
        """Get recommended filter string for a specific OTP source type"""
        filters = {
            'web': 'http contains "otp" or http contains "verification" or http contains "2fa"',
            'sms': 'tcp contains "sms" or tcp contains "text message" or http contains "twilio"',
            'email': 'tcp contains "smtp" or tcp contains "imap" or tcp contains "email"'
        }

        return filters.get(source_type, 'http or https')
