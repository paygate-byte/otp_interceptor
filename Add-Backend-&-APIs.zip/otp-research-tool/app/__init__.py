import os
from flask import Flask, render_template
from flask_bcrypt import Bcrypt
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

# Initialize extensions
db = SQLAlchemy()
bcrypt = Bcrypt()
migrate = Migrate()

def create_app(config_class=None):
    app = Flask(__name__)

    # Load configuration
    if config_class is None:
        from app.config import Config
        app.config.from_object(Config)
    else:
        app.config.from_object(config_class)

    # Initialize extensions with app
    db.init_app(app)
    bcrypt.init_app(app)
    migrate.init_app(app, db)

    # Ensure upload directories exist
    for directory in [app.config['UPLOAD_FOLDER'],
                     os.path.join(app.config['UPLOAD_FOLDER'], 'pcap'),
                     os.path.join(app.config['UPLOAD_FOLDER'], 'reports')]:
        os.makedirs(directory, exist_ok=True)

    # Import and register routes
    from app import routes

    # Register error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('errors/500.html'), 500

    # Create database tables
    with app.app_context():
        db.create_all()
        create_default_user()

    return app

def create_default_user():
    """Create a default admin user if it doesn't exist"""
    from app.models import User

    # Check if the default user already exists
    if User.query.filter_by(username="COLLINS").first() is None:
        default_user = User(
            username="COLLINS",
            is_admin=True
        )
        default_user.password = "Otp@001"  # This will be hashed in the model

        db.session.add(default_user)
        db.session.commit()
        print("Default admin user created.")

# Create application instance
app = create_app()

# Import models to ensure they are registered with SQLAlchemy
from app import models
