import os
import re
import json
import base64
import random
import string
import hashlib
import subprocess
import requests
from datetime import datetime
from functools import wraps
from typing import Dict, List, Optional, Union, Tuple, Any
from flask import request, flash, redirect, url_for, current_app, session
from app.models import db, User, ActivityLog, APITransaction, CapturedOTP

# Utility functions for handling files
def allowed_file(filename: str) -> bool:
    """Check if the file extension is allowed"""
    if '.' not in filename:
        return False
    ext = filename.rsplit('.', 1)[1].lower()
    return ext in current_app.config['ALLOWED_EXTENSIONS']

def secure_filename(filename: str) -> str:
    """Make a filename secure by removing unsafe characters"""
    # This is a simplified version - in production use werkzeug.utils.secure_filename
    # Remove bad characters and normalize whitespace
    filename = re.sub(r'[^\w\s.-]', '', filename)
    filename = re.sub(r'\s+', '_', filename).strip()
    return filename

def ensure_dir(directory: str) -> str:
    """Ensure a directory exists, creating it if necessary"""
    if not os.path.exists(directory):
        os.makedirs(directory)
    return directory

def generate_file_hash(file_path: str) -> str:
    """Generate MD5 hash of a file"""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

# Security helpers
def generate_csrf_token() -> str:
    """Generate a CSRF token"""
    token = base64.b64encode(os.urandom(32)).decode('utf-8')
    return token

def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            flash('Authentication required', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def require_admin(f):
    """Decorator to require admin privileges"""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            flash('Authentication required', 'danger')
            return redirect(url_for('login'))

        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            flash('Administrator privileges required', 'danger')
            return redirect(url_for('index'))

        return f(*args, **kwargs)
    return decorated

def log_activity(user_id: Optional[int], activity_type: str, description: str,
                 ip_address: Optional[str] = None, details: Optional[Dict] = None):
    """Log user activity to the database"""
    if ip_address is None:
        ip_address = request.remote_addr

    log_entry = ActivityLog(
        activity_type=activity_type,
        description=description,
        ip_address=ip_address,
        user_id=user_id
    )

    if details:
        log_entry.set_details_dict(details)

    db.session.add(log_entry)
    db.session.commit()

    return log_entry
