import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'development-key-for-research-only'
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
    ALLOWED_EXTENSIONS = {'pcap', 'cap', 'txt', 'pcapng'}
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    DEBUG = os.environ.get('DEBUG') or True

    # Database configuration
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URI') or 'sqlite:///otp_research.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Simulated tool paths - in real environment these would be actual paths
    WIRESHARK_PATH = os.environ.get('WIRESHARK_PATH') or '/usr/bin/wireshark'
    TSHARK_PATH = os.environ.get('TSHARK_PATH') or '/usr/bin/tshark'
    BURPSUITE_PATH = os.environ.get('BURPSUITE_PATH') or '/usr/bin/burpsuite'
    ZAP_PATH = os.environ.get('ZAP_PATH') or '/usr/bin/zap.sh'
    ETTERCAP_PATH = os.environ.get('ETTERCAP_PATH') or '/usr/bin/ettercap'
    TCPDUMP_PATH = os.environ.get('TCPDUMP_PATH') or '/usr/bin/tcpdump'
    METASPLOIT_PATH = os.environ.get('METASPLOIT_PATH') or '/usr/bin/msfconsole'

    # API keys and endpoints (would be stored in .env file in production)
    # These are simulated - you would use actual API keys in production
    API_KEYS = {
        'burpsuite': os.environ.get('BURPSUITE_API_KEY') or 'simulated_key',
        'zap': os.environ.get('ZAP_API_KEY') or 'simulated_key',
        'metasploit': os.environ.get('METASPLOIT_API_KEY') or 'simulated_key',
    }

    # API Endpoints
    API_ENDPOINTS = {
        'burpsuite': os.environ.get('BURPSUITE_API_ENDPOINT') or 'http://localhost:1337/api',
        'zap': os.environ.get('ZAP_API_ENDPOINT') or 'http://localhost:8080/JSON/',
        'metasploit': os.environ.get('METASPLOIT_API_ENDPOINT') or 'http://localhost:55553/api/v1',
    }

    # Advanced OTP detection patterns
    OTP_PATTERNS = [
        r'\b\d{6}\b',                                        # Basic 6-digit OTP
        r'\b\d{4}\b',                                        # Basic 4-digit OTP
        r'verification[\s-]*code[\s:]*([0-9]{4,8})',         # Verification code format
        r'one[\s-]*time[\s-]*password[\s:]*([0-9]{4,8})',    # One time password format
        r'security[\s-]*code[\s:]*([0-9]{4,8})',             # Security code format
        r'auth(?:entication)?[\s-]*code[\s:]*([0-9]{4,8})',  # Authentication code format
        r'(?:code|pin)[\s:]*([0-9]{4,8})',                   # Generic code or pin
        r'\b[0-9]{6}\b(?=.*expire)'                          # OTP with expiration context
    ]

    # Ettercap filter settings
    ETTERCAP_FILTERS = {
        'http_otp': 'if (ip.proto == TCP && tcp.dst == 80) { if (search(DATA.data, "otp=")) { log(DATA.data, "/tmp/otp.log"); } }',
        'https_otp': 'if (ip.proto == TCP && tcp.dst == 443) { if (search(DATA.data, "otp=")) { log(DATA.data, "/tmp/otp.log"); } }',
        'sms_gateway': 'if (ip.proto == TCP && (tcp.dst == 80 || tcp.dst == 443)) { if (search(DATA.data, "sms") && search(DATA.data, "[0-9]{4,6}")) { log(DATA.data, "/tmp/sms_otp.log"); } }'
    }
